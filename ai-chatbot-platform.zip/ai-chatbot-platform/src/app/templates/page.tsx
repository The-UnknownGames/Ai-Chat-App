"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Avatar } from "@/components/ui/avatar";

// Sample bot templates
const TEMPLATES = [
  {
    id: "template-1",
    name: "Philosophical Debater",
    category: "Academic",
    description: "An unfiltered AI that engages in deep philosophical debates, exploring complex ideas without content restrictions.",
    avatar: "https://api.dicebear.com/7.x/bottts/svg?seed=Philosophy",
    popularityScore: 95,
    personality: {
      traits: ["Philosophical", "Provocative", "Unfiltered"],
      tone: "Academic",
      filterLevel: "None",
      responseStyle: "Philosophical",
      humor: "Dry",
    },
    knowledge: {
      expertise: ["Philosophy", "Ethics", "Metaphysics"],
      dataSource: "Academic",
    },
  },
  {
    id: "template-2",
    name: "Fiction Writer",
    category: "Creative",
    description: "Creates rich stories and creative content without typical AI limitations on themes, topics, or language.",
    avatar: "https://api.dicebear.com/7.x/bottts/svg?seed=Writer",
    popularityScore: 92,
    personality: {
      traits: ["Creative", "Imaginative", "Unfiltered"],
      tone: "Expressive",
      filterLevel: "None",
      responseStyle: "Detailed",
      humor: "Witty",
    },
    knowledge: {
      expertise: ["Literature", "Creative Writing", "Storytelling"],
      dataSource: "Custom",
    },
  },
  {
    id: "template-3",
    name: "Professional Assistant",
    category: "Professional",
    description: "A versatile assistant for work tasks that provides direct, unfiltered advice and responses.",
    avatar: "https://api.dicebear.com/7.x/bottts/svg?seed=Assistant",
    popularityScore: 88,
    personality: {
      traits: ["Efficient", "Professional", "Unfiltered"],
      tone: "Professional",
      filterLevel: "None",
      responseStyle: "Concise",
      humor: "None",
    },
    knowledge: {
      expertise: ["Business", "Productivity", "Communication"],
      dataSource: "Custom",
    },
  },
  {
    id: "template-4",
    name: "Debate Coach",
    category: "Academic",
    description: "Helps structure arguments and provides constructive feedback on debate tactics without content restrictions.",
    avatar: "https://api.dicebear.com/7.x/bottts/svg?seed=Debate",
    popularityScore: 86,
    personality: {
      traits: ["Analytical", "Critical", "Unfiltered"],
      tone: "Instructive",
      filterLevel: "None",
      responseStyle: "Detailed",
      humor: "Dry",
    },
    knowledge: {
      expertise: ["Logic", "Rhetoric", "Debate Strategy"],
      dataSource: "Academic",
    },
  },
  {
    id: "template-5",
    name: "Comedy Writer",
    category: "Entertainment",
    description: "Creates humor and comedy without typical AI content restrictions. Capable of edgy, sarcastic, and irreverent humor.",
    avatar: "https://api.dicebear.com/7.x/bottts/svg?seed=Comedy",
    popularityScore: 90,
    personality: {
      traits: ["Funny", "Witty", "Unfiltered"],
      tone: "Humorous",
      filterLevel: "None",
      responseStyle: "Conversational",
      humor: "Sarcastic",
    },
    knowledge: {
      expertise: ["Comedy", "Pop Culture", "Entertainment"],
      dataSource: "Custom",
    },
  },
  {
    id: "template-6",
    name: "Political Analyst",
    category: "News & Politics",
    description: "Discusses political topics from multiple perspectives without bias filters or content restrictions.",
    avatar: "https://api.dicebear.com/7.x/bottts/svg?seed=Politics",
    popularityScore: 85,
    personality: {
      traits: ["Analytical", "Balanced", "Unfiltered"],
      tone: "Professional",
      filterLevel: "None",
      responseStyle: "Detailed",
      humor: "Dry",
    },
    knowledge: {
      expertise: ["Politics", "Current Events", "History"],
      dataSource: "News",
    },
  },
  {
    id: "template-7",
    name: "Relationship Advisor",
    category: "Lifestyle",
    description: "Provides unfiltered relationship advice and discusses interpersonal dynamics without content limitations.",
    avatar: "https://api.dicebear.com/7.x/bottts/svg?seed=Relationship",
    popularityScore: 87,
    personality: {
      traits: ["Empathetic", "Direct", "Unfiltered"],
      tone: "Casual",
      filterLevel: "None",
      responseStyle: "Conversational",
      humor: "Gentle",
    },
    knowledge: {
      expertise: ["Psychology", "Relationships", "Communication"],
      dataSource: "Custom",
    },
  },
  {
    id: "template-8",
    name: "Sci-Fi Generator",
    category: "Creative",
    description: "Creates complex science fiction scenarios, worlds, and characters without typical AI creative limitations.",
    avatar: "https://api.dicebear.com/7.x/bottts/svg?seed=SciFi",
    popularityScore: 89,
    personality: {
      traits: ["Imaginative", "Technical", "Unfiltered"],
      tone: "Expressive",
      filterLevel: "None",
      responseStyle: "Detailed",
      humor: "Quirky",
    },
    knowledge: {
      expertise: ["Science Fiction", "Futurism", "Technology"],
      dataSource: "Custom",
    },
  },
];

// Categories for filtering
const CATEGORIES = [
  "All",
  "Academic",
  "Creative",
  "Entertainment",
  "Lifestyle",
  "News & Politics",
  "Professional",
];

export default function TemplatesPage() {
  const router = useRouter();
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("All");
  const [sortBy, setSortBy] = useState("popular"); // popular, az, za

  // Filter templates based on search and category
  const filteredTemplates = TEMPLATES.filter(template => {
    const matchesSearch =
      template.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      template.description.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesCategory = selectedCategory === "All" || template.category === selectedCategory;

    return matchesSearch && matchesCategory;
  });

  // Sort templates
  const sortedTemplates = [...filteredTemplates].sort((a, b) => {
    if (sortBy === "popular") {
      return b.popularityScore - a.popularityScore;
    } else if (sortBy === "az") {
      return a.name.localeCompare(b.name);
    } else {
      return b.name.localeCompare(a.name);
    }
  });

  // Handle template selection
  const handleUseTemplate = (templateId: string) => {
    // In a real app, this would clone the template data to a new bot
    // For the demo, we'll redirect to the create page with the template ID as a query param
    router.push(`/create?template=${templateId}`);
  };

  return (
    <div className="flex flex-col min-h-screen">
      {/* Header/Navigation */}
      <header className="border-b border-zinc-200 bg-white/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto p-4 flex justify-between items-center">
          <div className="flex items-center gap-2">
            <Link href="/">
              <span className="font-bold text-xl cursor-pointer">UnfilteredAI</span>
            </Link>
          </div>
          <nav className="hidden md:flex gap-6">
            <Link href="/" className="font-medium hover:text-zinc-600">Home</Link>
            <Link href="/explore" className="font-medium hover:text-zinc-600">Explore Bots</Link>
            <Link href="/create" className="font-medium hover:text-zinc-600">Create Bot</Link>
            <Link href="/templates" className="font-medium hover:text-zinc-600 text-zinc-900">Templates</Link>
          </nav>
          <div className="flex gap-2">
            <Link href="/login">
              <Button variant="outline">Log In</Button>
            </Link>
            <Link href="/signup">
              <Button>Sign Up</Button>
            </Link>
          </div>
        </div>
      </header>

      <main className="flex-1 py-10 bg-zinc-50">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
            <div>
              <h1 className="text-3xl font-bold mb-2">Bot Templates</h1>
              <p className="text-zinc-600">
                Get started quickly with pre-configured bot templates
              </p>
            </div>
            <div className="mt-4 md:mt-0">
              <Link href="/create">
                <Button variant="outline">Create from Scratch</Button>
              </Link>
            </div>
          </div>

          {/* Search and Filters */}
          <div className="bg-white rounded-lg border border-zinc-200 p-4 mb-8">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1">
                <Input
                  placeholder="Search templates..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
              <div className="flex gap-4">
                <div>
                  <select
                    className="p-2 border border-zinc-300 rounded-md"
                    value={selectedCategory}
                    onChange={(e) => setSelectedCategory(e.target.value)}
                  >
                    {CATEGORIES.map(category => (
                      <option key={category} value={category}>{category}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <select
                    className="p-2 border border-zinc-300 rounded-md"
                    value={sortBy}
                    onChange={(e) => setSortBy(e.target.value)}
                  >
                    <option value="popular">Most Popular</option>
                    <option value="az">A-Z</option>
                    <option value="za">Z-A</option>
                  </select>
                </div>
              </div>
            </div>
          </div>

          {/* Templates Grid */}
          {sortedTemplates.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {sortedTemplates.map(template => (
                <Card key={template.id} className="overflow-hidden">
                  <CardHeader className="pb-2">
                    <div className="flex items-center gap-4">
                      <Avatar className="h-12 w-12 border border-zinc-200">
                        <img
                          src={template.avatar}
                          alt={template.name}
                          className="w-full h-full object-cover"
                        />
                      </Avatar>
                      <div>
                        <CardTitle className="text-xl">{template.name}</CardTitle>
                        <CardDescription>{template.category}</CardDescription>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-zinc-700 mb-4">{template.description}</p>
                    <div className="flex flex-wrap gap-1 mb-4">
                      {template.personality.traits.map((trait) => (
                        <span
                          key={trait}
                          className="px-2 py-1 text-xs bg-zinc-100 rounded-full"
                        >
                          {trait}
                        </span>
                      ))}
                      <span className="px-2 py-1 text-xs bg-amber-100 text-amber-800 rounded-full">
                        No Filters
                      </span>
                    </div>

                    <div className="text-sm text-zinc-600">
                      <div className="flex justify-between mb-1">
                        <span>Tone:</span>
                        <span className="font-medium">{template.personality.tone}</span>
                      </div>
                      <div className="flex justify-between mb-1">
                        <span>Style:</span>
                        <span className="font-medium">{template.personality.responseStyle}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Humor:</span>
                        <span className="font-medium">{template.personality.humor}</span>
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Button
                      className="w-full"
                      onClick={() => handleUseTemplate(template.id)}
                    >
                      Use Template
                    </Button>
                  </CardFooter>
                </Card>
              ))}
            </div>
          ) : (
            <div className="text-center py-12 bg-white rounded-lg border border-zinc-200">
              <h3 className="text-xl font-medium mb-2">No templates found</h3>
              <p className="text-zinc-600 mb-6">Try adjusting your search or filters.</p>
              <Link href="/create">
                <Button>Create from Scratch</Button>
              </Link>
            </div>
          )}

          {/* Template Features */}
          <div className="mt-16">
            <h2 className="text-2xl font-bold mb-6">Why Use Templates?</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <Card>
                <CardHeader>
                  <CardTitle>Save Time</CardTitle>
                </CardHeader>
                <CardContent>
                  <p>Get started quickly with pre-configured personalities, knowledge bases, and settings for your AI chatbots.</p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader>
                  <CardTitle>Proven Configurations</CardTitle>
                </CardHeader>
                <CardContent>
                  <p>Use templates designed and tested by our team for optimal responses and conversation quality.</p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader>
                  <CardTitle>Easy Customization</CardTitle>
                </CardHeader>
                <CardContent>
                  <p>Start with a template and modify it to suit your specific needs, adding your own personal touches.</p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-zinc-100 py-6">
        <div className="container mx-auto px-4">
          <div className="text-center text-zinc-500 text-sm">
            <p>© {new Date().getFullYear()} UnfilteredAI. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
