"use client";

import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

export default function ApiDocumentationPage() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Header/Navigation */}
      <header className="border-b border-zinc-200 bg-white/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto p-4 flex justify-between items-center">
          <div className="flex items-center gap-2">
            <Link href="/">
              <span className="font-bold text-xl cursor-pointer">UnfilteredAI</span>
            </Link>
          </div>
          <nav className="hidden md:flex gap-6">
            <Link href="/" className="font-medium hover:text-zinc-600">Home</Link>
            <Link href="/explore" className="font-medium hover:text-zinc-600">Explore Bots</Link>
            <Link href="/create" className="font-medium hover:text-zinc-600">Create Bot</Link>
            <Link href="/api/documentation" className="font-medium text-zinc-900">API Docs</Link>
          </nav>
          <div className="flex gap-2">
            <Link href="/login">
              <Button variant="outline">Log In</Button>
            </Link>
            <Link href="/signup">
              <Button>Sign Up</Button>
            </Link>
          </div>
        </div>
      </header>

      {/* Main content - simplified version */}
      <main className="flex-1 py-10 bg-zinc-50">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
            <div>
              <h1 className="text-3xl font-bold mb-2">API Documentation</h1>
              <p className="text-zinc-600">
                Integrate AI chatbots into your own applications
              </p>
            </div>
            <div className="mt-4 md:mt-0">
              <Link href="/api/keys">
                <Button>Get API Key</Button>
              </Link>
            </div>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Introduction</CardTitle>
              <CardDescription>
                Getting started with the AI Chatbot API
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <p>
                The AI Chatbot API allows you to integrate AI chatbots into your own applications.
                You can browse available bots, get bot details, and chat with bots using our simple REST API.
              </p>
              <p>
                Our API provides access to a wide range of AI chatbots with various personalities and knowledge bases.
                All API requests are made to our base URL:
              </p>
              <div className="bg-zinc-900 text-zinc-100 p-4 rounded-md font-mono text-sm">
                https://api.example.com/v1
              </div>
            </CardContent>
          </Card>
        </div>
      </main>

      {/* Simple Footer */}
      <footer className="bg-zinc-100 py-6">
        <div className="container mx-auto px-4">
          <div className="text-center text-zinc-500 text-sm">
            <p>© {new Date().getFullYear()} AI Chatbot Platform. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
