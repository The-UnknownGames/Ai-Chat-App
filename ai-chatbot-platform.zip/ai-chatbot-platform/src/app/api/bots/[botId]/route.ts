// This file is disabled for static export
/*
import { NextResponse } from "next/server";

export async function GET(
  request: Request,
) {
  // Extract botId from path segments
  const url = new URL(request.url);
  const pathSegments = url.pathname.split('/');
  const botId = pathSegments[pathSegments.length - 1];

  return NextResponse.json({
    status: "success",
    data: {
      id: botId,
      name: "Sample Bot",
      description: "This is a sample bot response for the deployment test",
    }
  });
}

export async function POST(
  request: Request,
) {
  // Extract botId from path segments
  const url = new URL(request.url);
  const pathSegments = url.pathname.split('/');
  const botId = pathSegments[pathSegments.length - 1];

  try {
    const body = await request.json();

    return NextResponse.json({
      status: "success",
      data: {
        botId: botId,
        message: body.message || "No message provided",
        response: "This is a test response for deployment",
        timestamp: new Date().toISOString(),
      }
    });
  } catch (error) {
    return NextResponse.json(
      { status: "error", message: "Invalid request body" },
      { status: 400 }
    );
  }
}
*/
