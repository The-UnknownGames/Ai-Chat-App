// This file is disabled for static export
/*
import { NextResponse } from "next/server";

export async function GET(request: Request) {
  // Sample data for demonstration
  const sampleBots = [
    {
      id: "1",
      name: "Philosophical Debater",
      description: "AI for philosophical debates",
      avatar: "https://api.dicebear.com/7.x/bottts/svg?seed=Philosophy",
    },
    {
      id: "2",
      name: "Political Analyst",
      description: "Discusses political topics",
      avatar: "https://api.dicebear.com/7.x/bottts/svg?seed=Politics",
    },
    {
      id: "3",
      name: "Creative Writer",
      description: "AI fiction writer",
      avatar: "https://api.dicebear.com/7.x/bottts/svg?seed=Writer",
    }
  ];

  return NextResponse.json({
    status: "success",
    count: sampleBots.length,
    data: sampleBots
  });
}
*/
