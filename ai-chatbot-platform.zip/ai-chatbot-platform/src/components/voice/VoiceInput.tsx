"use client";

import { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";

// Add the missing type definition at the top
interface SpeechRecognition extends EventTarget {
  continuous: boolean;
  interimResults: boolean;
  lang: string;
  start: () => void;
  stop: () => void;
  onstart: (event: Event) => void;
  onresult: (event: SpeechRecognitionEvent) => void;
  onerror: (event: SpeechRecognitionErrorEvent) => void;
  onend: (event: Event) => void;
}

interface SpeechRecognitionEvent {
  resultIndex: number;
  results: SpeechRecognitionResultList;
}

interface SpeechRecognitionResultList {
  length: number;
  [index: number]: SpeechRecognitionResult;
}

interface SpeechRecognitionResult {
  isFinal: boolean;
  [index: number]: SpeechRecognitionAlternative;
}

interface SpeechRecognitionAlternative {
  transcript: string;
}

interface SpeechRecognitionErrorEvent extends Event {
  error: string;
}

interface VoiceInputProps {
  onResult: (transcript: string) => void;
  language?: string;
  placeholder?: string;
  isListening?: boolean;
  setIsListening?: (isListening: boolean) => void;
  autoStop?: number; // milliseconds after which to stop listening
}

export function VoiceInput({
  onResult,
  language = "en-US",
  placeholder = "Listening...",
  isListening: externalIsListening,
  setIsListening: externalSetIsListening,
  autoStop = 10000, // 10 seconds default
}: VoiceInputProps) {
  const [isListening, setLocalIsListening] = useState(false);
  const [transcript, setTranscript] = useState("");
  const [error, setError] = useState<string | null>(null);
  const recognitionRef = useRef<SpeechRecognition | null>(null);
  const timeoutRef = useRef<NodeJS.Timeout | null>(null);

  // Use either external or local state for controlling listening
  const effectiveIsListening = externalIsListening !== undefined ? externalIsListening : isListening;
  const effectiveSetIsListening = externalSetIsListening || setLocalIsListening;

  useEffect(() => {
    // Check if browser supports SpeechRecognition
    if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
      setError("Speech recognition is not supported in this browser.");
      return;
    }

    // Initialize SpeechRecognition
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    recognitionRef.current = new SpeechRecognition();

    // Configure recognition
    const recognition = recognitionRef.current;
    recognition.continuous = true;
    recognition.interimResults = true;
    recognition.lang = language;

    // Set up event handlers
    recognition.onstart = () => {
      setTranscript("");
      setError(null);
      effectiveSetIsListening(true);

      // Set timeout to automatically stop listening after autoStop milliseconds
      if (autoStop > 0) {
        if (timeoutRef.current) clearTimeout(timeoutRef.current);
        timeoutRef.current = setTimeout(() => {
          if (recognitionRef.current) {
            recognitionRef.current.stop();
          }
        }, autoStop);
      }
    };

    recognition.onresult = (event) => {
      let interimTranscript = '';
      let finalTranscript = '';

      for (let i = event.resultIndex; i < event.results.length; ++i) {
        if (event.results[i].isFinal) {
          finalTranscript += event.results[i][0].transcript;
        } else {
          interimTranscript += event.results[i][0].transcript;
        }
      }

      // Update transcript
      setTranscript(finalTranscript || interimTranscript);

      // If final transcript is available, pass it to the callback
      if (finalTranscript) {
        onResult(finalTranscript);
      }
    };

    recognition.onerror = (event) => {
      if (event.error === 'no-speech') {
        setError("No speech detected. Please try again.");
      } else if (event.error === 'audio-capture') {
        setError("No microphone detected.");
      } else if (event.error === 'not-allowed') {
        setError("Microphone access denied.");
      } else {
        setError(`Error: ${event.error}`);
      }
      effectiveSetIsListening(false);
    };

    recognition.onend = () => {
      effectiveSetIsListening(false);
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
        timeoutRef.current = null;
      }
    };

    // Clean up event listeners on unmount
    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
      }
    };
  }, [language, onResult, effectiveSetIsListening, autoStop]);

  const toggleListening = () => {
    if (effectiveIsListening) {
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
      effectiveSetIsListening(false);
    } else {
      if (recognitionRef.current) {
        recognitionRef.current.start();
      }
      effectiveSetIsListening(true);
    }
  };

  return (
    <div className="flex flex-col space-y-2">
      <div className="flex items-center gap-2">
        <Button
          type="button"
          variant={effectiveIsListening ? "default" : "outline"}
          size="sm"
          onClick={toggleListening}
          className={effectiveIsListening ? "bg-red-500 hover:bg-red-600 text-white" : ""}
        >
          {effectiveIsListening ? (
            <>
              <MicrophoneIcon className="h-4 w-4 mr-1 animate-pulse" />
              Stop
            </>
          ) : (
            <>
              <MicrophoneIcon className="h-4 w-4 mr-1" />
              Start Voice
            </>
          )}
        </Button>

        {effectiveIsListening && (
          <div className="text-sm font-medium animate-pulse">
            {transcript || placeholder}
          </div>
        )}
      </div>

      {error && (
        <div className="text-sm text-red-500">{error}</div>
      )}
    </div>
  );
}

function MicrophoneIcon({ className }: { className?: string }) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
    >
      <path d="M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3Z"></path>
      <path d="M19 10v2a7 7 0 0 1-14 0v-2"></path>
      <line x1="12" x2="12" y1="19" y2="22"></line>
    </svg>
  );
}

// Update the global declaration at the bottom
declare global {
  interface Window {
    SpeechRecognition: new () => SpeechRecognition;
    webkitSpeechRecognition: new () => SpeechRecognition;
  }
}
