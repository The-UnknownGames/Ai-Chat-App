"use client";

import { useState, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";

interface KnowledgeBaseImporterProps {
  onImport: (data: string, format: string, name: string) => void;
}

export function KnowledgeBaseImporter({ onImport }: KnowledgeBaseImporterProps) {
  const [activeTab, setActiveTab] = useState<string>("file");
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [fileError, setFileError] = useState<string | null>(null);
  const [urlInput, setUrlInput] = useState<string>("");
  const [urlError, setUrlError] = useState<string | null>(null);
  const [textInput, setTextInput] = useState<string>("");
  const [dataSourceName, setDataSourceName] = useState<string>("");
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Supported file types
  const supportedFileTypes = ["text/plain", "application/json", "text/csv", "application/pdf", "text/markdown"];
  const fileExtensionMap: Record<string, string> = {
    "text/plain": "TXT",
    "application/json": "JSON",
    "text/csv": "CSV",
    "application/pdf": "PDF",
    "text/markdown": "MD"
  };

  // Handle file selection
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    setFileError(null);

    if (!file) {
      setSelectedFile(null);
      return;
    }

    if (!supportedFileTypes.includes(file.type)) {
      setFileError(`Unsupported file type. Please upload a ${supportedFileTypes.map(t => fileExtensionMap[t]).join(', ')} file.`);
      setSelectedFile(null);
      return;
    }

    setSelectedFile(file);
    setDataSourceName(file.name.split('.')[0]);
  };

  // Parse file content
  const parseFile = async (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();

      reader.onload = (e) => {
        const content = e.target?.result as string;
        resolve(content);
      };

      reader.onerror = () => {
        reject(new Error("Error reading file"));
      };

      if (file.type === "application/pdf") {
        // In a real implementation, you'd need a PDF parsing library
        // For demo purposes, we'll just return a placeholder message
        resolve("PDF content would be extracted here in a real implementation.");
      } else {
        reader.readAsText(file);
      }
    });
  };

  // Fetch URL content
  const fetchUrl = async (url: string): Promise<string> => {
    try {
      // In a real implementation, this would be a server-side call
      // For demo purposes, we'll simulate a response
      await new Promise(resolve => setTimeout(resolve, 1500));
      return `Content from ${url} would be fetched here in a real implementation.`;
    } catch (error) {
      throw new Error("Error fetching URL content");
    }
  };

  // Handle import submission
  const handleImport = async () => {
    setIsLoading(true);
    setFileError(null);
    setUrlError(null);

    try {
      let importedData = "";
      let format = "text";

      switch (activeTab) {
        case "file":
          if (!selectedFile) {
            setFileError("Please select a file to import.");
            setIsLoading(false);
            return;
          }
          importedData = await parseFile(selectedFile);
          format = fileExtensionMap[selectedFile.type] || "text";
          break;

        case "url":
          if (!urlInput) {
            setUrlError("Please enter a URL to import.");
            setIsLoading(false);
            return;
          }
          importedData = await fetchUrl(urlInput);
          format = "url";
          break;

        case "text":
          if (!textInput.trim()) {
            setIsLoading(false);
            return;
          }
          importedData = textInput;
          format = "text";
          break;
      }

      // Name is required
      if (!dataSourceName.trim()) {
        setDataSourceName("Imported Knowledge " + new Date().toLocaleDateString());
      }

      // Call the onImport callback with the parsed data
      onImport(importedData, format, dataSourceName);

      // Reset form
      setSelectedFile(null);
      setUrlInput("");
      setTextInput("");
      if (fileInputRef.current) fileInputRef.current.value = "";

    } catch (error) {
      if (activeTab === "file") {
        setFileError("Error parsing file. Please try again.");
      } else if (activeTab === "url") {
        setUrlError("Error fetching URL. Please check the URL and try again.");
      }
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Card className="max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle>Import Knowledge Base</CardTitle>
        <CardDescription>
          Import training data and knowledge for your AI chatbot from various sources.
        </CardDescription>
      </CardHeader>

      <CardContent>
        <div className="space-y-4">
          <div>
            <label htmlFor="dataSourceName" className="block text-sm font-medium mb-1">
              Knowledge Base Name
            </label>
            <Input
              id="dataSourceName"
              value={dataSourceName}
              onChange={(e) => setDataSourceName(e.target.value)}
              placeholder="My Custom Knowledge Base"
            />
          </div>

          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid grid-cols-3">
              <TabsTrigger value="file">File Upload</TabsTrigger>
              <TabsTrigger value="url">Import from URL</TabsTrigger>
              <TabsTrigger value="text">Paste Text</TabsTrigger>
            </TabsList>

            <TabsContent value="file" className="space-y-4">
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
                <input
                  ref={fileInputRef}
                  type="file"
                  onChange={handleFileChange}
                  className="hidden"
                  accept=".txt,.json,.csv,.pdf,.md"
                />

                <div className="mb-4">
                  <DocumentIcon className="mx-auto h-12 w-12 text-gray-400" />
                  <p className="mt-2 text-sm text-gray-600">
                    {selectedFile ? selectedFile.name : "Upload a file to import knowledge"}
                  </p>
                  <p className="text-xs text-gray-500 mt-1">
                    Supports TXT, JSON, CSV, PDF, and Markdown files
                  </p>
                </div>

                <Button
                  variant="outline"
                  onClick={() => fileInputRef.current?.click()}
                >
                  Choose File
                </Button>

                {fileError && (
                  <p className="text-sm text-red-500 mt-2">{fileError}</p>
                )}
              </div>
            </TabsContent>

            <TabsContent value="url" className="space-y-4">
              <div>
                <label htmlFor="urlInput" className="block text-sm font-medium mb-1">
                  URL to Import
                </label>
                <Input
                  id="urlInput"
                  value={urlInput}
                  onChange={(e) => setUrlInput(e.target.value)}
                  placeholder="https://example.com/knowledge.txt"
                />
                <p className="text-xs text-gray-500 mt-1">
                  Enter the URL of a text, JSON, or Markdown file to import
                </p>

                {urlError && (
                  <p className="text-sm text-red-500 mt-2">{urlError}</p>
                )}
              </div>
            </TabsContent>

            <TabsContent value="text" className="space-y-4">
              <div>
                <label htmlFor="textInput" className="block text-sm font-medium mb-1">
                  Paste Text Content
                </label>
                <Textarea
                  id="textInput"
                  value={textInput}
                  onChange={(e) => setTextInput(e.target.value)}
                  placeholder="Paste text data here..."
                  rows={10}
                />
                <p className="text-xs text-gray-500 mt-1">
                  Paste text, JSON, or Markdown content directly
                </p>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </CardContent>

      <CardFooter>
        <div className="w-full flex justify-end">
          <Button
            onClick={handleImport}
            disabled={isLoading}
          >
            {isLoading ? "Importing..." : "Import Knowledge Base"}
          </Button>
        </div>
      </CardFooter>
    </Card>
  );
}

function DocumentIcon({ className }: { className?: string }) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
    >
      <path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z" />
      <polyline points="14 2 14 8 20 8" />
    </svg>
  );
}
